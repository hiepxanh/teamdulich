from flask import Flask
from flask import render_template
from posts import Post

app = Flask(__name__)


@app.route('/')
def hello_world():
    return 'Hello World!'

posts = [
            Post("Hiệp cùng gấu đã ị chung ở đây",
              "Không thể dừng lại được"),
            Post("Fuma đã ở đây",
              "Quyền Anh đi rình Fuma")
         ]

@app.route('/post/<post_id>')
def get_posts(post_id = None):
    post = posts[int(post_id)]
    #return post.content

    #post = posts[post_id]
    #content = "Không thể dùng từ đẹp để nói về cao nguyên Mộc Châu, mà phải dùng từ “tuyệt vời”! Một vùng đất hiền hòa, hiếu khách, đồi chè xanh, dải lụa trắng dệt từ hoa cải, chén rượu ngô và những bông hoa mận nở trắng rừng… tất cả những hình ảnh ấy sẽ in hằn trong kỹ ức của bất cứ kẽ lữ hành nào đến đây. Mộc Châu như một người thiếu nữ Tây Bắc, thân thiện, hiếu khách và mộc mạc với một tấm chân tình."
    return render_template('post.html', post_ = post)

if __name__ == '__main__':
    app.run()
