__author__ = 'qhuydtvt'

class Post:
    def __init__(self, _title, _content):
        self.title = _title
        self.content = _content

